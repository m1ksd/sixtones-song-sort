import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// GitHub Pages serves the project from /<repo-name>/, so the base path
// must match your repository name. Update BASE_PATH if you rename the repo.
const BASE_PATH = "/sixtones-song-sort/";

export default defineConfig({
  plugins: [react()],
  base: BASE_PATH,
});
