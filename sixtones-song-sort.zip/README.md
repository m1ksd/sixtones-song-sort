# SixTONES SONG SORT

「どっちが好き？」を約40回繰り返して、自分だけのSixTONES楽曲TOP10を作るファンメイドWebアプリ。
React + Vite + TypeScript / バックエンドなし / ユーザー登録なし / 個人情報を収集しない。

## セットアップ

```bash
npm install
npm run dev
```

`http://localhost:5173` で確認できます。

## GitHub Pagesへのデプロイ

このリポジトリ名が `sixtones-song-sort` 以外の場合は、次の2箇所を実際のリポジトリ名に合わせて変更してください。

- `vite.config.ts` の `BASE_PATH`
- `package.json` の `homepage`（あなたのGitHubユーザー名に変更）

### 方法A: GitHub Actions（推奨・自動）

`.github/workflows/deploy.yml` を同梱済みです。GitHubリポジトリの
Settings → Pages → Source を **GitHub Actions** に設定し、`main` ブランチに
pushするだけで自動ビルド・公開されます。

### 方法B: 手動デプロイ（gh-pages）

```bash
npm run build
npm run deploy
```

## 設計メモ / 重要な制約

- **Spotify URL・楽曲データは確定データです。** `src/data/songs.ts` 内のURLは
  ユーザーが確認済みのものをそのまま使用しています。再検索・自動変更はしていません。
  Spotify Embed / Player / API / OAuthは一切使用せず、結果画面の「Spotifyで聴く ↗」
  という外部リンクのみで使用しています。
- **`id` はSpotifyのトラックIDとは無関係の内部キーです。** URLが変わってもランキング・
  共有データが壊れない設計です。既存の `id` は将来変更しないでください。新しい曲を
  追加する場合は、共有リンクの互換性のために `songs.ts` の末尾に追加してください
  （`src/lib/resultCodec.ts` の先頭コメント参照）。
- **`category` は未検証の目安ラベルです。** ランキングアルゴリズム（Elo）には一切影響しません。
  自由に修正して構いません。
- ランキングロジック（`src/lib/ranking.ts`）と出題ロジック（`src/lib/matchmaker.ts`）は
  UIから完全に分離しています。将来、出題アルゴリズムを「未比較ペア優先」「レート差が
  近いペア優先」などへ改善する際も、この2ファイルだけを差し替えれば済みます。
- 結果URLは `HashRouter` を使い `#/result/xxxx` の形式にしています。これはGitHub Pages
  のような静的ホスティングで、サーバー側のルーティング設定なしに直リンクを正しく
  開けるようにするための選択です。
- 結果画像はブラウザのCanvas APIで完結して生成しています（ジャケット画像は不使用）。
- 公式SixTONESサイトのデザイン・ロゴ・画像素材は使用していません。

## ディレクトリ構成

```
src/
  components/   SongCard, ProgressBar, Top10List, SpotifyLink
  data/         songs.ts（確定データ）
  lib/          ranking.ts, matchmaker.ts, resultCodec.ts, resultImage.ts
  pages/        StartPage, SortPage, ResultPage
  types/        song.ts, ranking.ts
```

## 未実装 / 今後の拡張候補（仕様書 Phase 4）

- 出題アルゴリズムの改善（未比較優先・レート差優先・TOP10候補の重点比較・同一ペア再出題防止）
- localStorageによる途中状態の保存
- 動的OGP（Cloudflare Workers等）
