export type Rating = {
  songId: string;
  rating: number;
  comparisons: number;
};

export type RatingsMap = Record<string, Rating>;

export type ComparisonPair = {
  a: string; // song id
  b: string; // song id
};

export type ComparisonRecord = ComparisonPair & {
  winner: string; // song id of the chosen song
};
