export type SongCategory =
  | "single"
  | "album"
  | "coupling"
  | "jr"
  | "solo";

export type SpotifyStatus = "confirmed" | "needs-review" | "not-available";

export type Song = {
  id: string;
  title: string;
  originalKey: string;
  category: SongCategory;

  spotifyStatus: SpotifyStatus;
  spotifyUrl?: string;

  recordingType: "original";

  notes?: string;
};
