import type { ComparisonPair } from "../types/ranking";

function shuffle<T>(items: T[]): T[] {
  const arr = items.slice();
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function pairKey(a: string, b: string): string {
  return a < b ? `${a}::${b}` : `${b}::${a}`;
}

/**
 * Builds the sequence of comparison pairs for one session.
 *
 * Current (MVP) strategy:
 *  1. Shuffle all songs and pair them up round-robin-style so that, in the
 *     first pass, as many different songs as possible get compared at least
 *     once (with ~75 songs and ~40 questions, one full pass already covers
 *     almost everyone).
 *  2. Fill any remaining question slots with additional random pairs,
 *     avoiding exact pair repeats where possible.
 *
 * This is intentionally simple. It is isolated here so it can be swapped
 * out later for a smarter strategy without touching ranking.ts or any UI
 * code. Planned future improvements (see project spec):
 *  - prioritize songs with the fewest comparisons so far
 *  - prioritize pairs with a small rating gap (more informative matchups)
 *  - spend extra comparisons narrowing down likely top-10 candidates
 *  - guarantee no pair is repeated within a single session
 */
export function generateMatchupSequence(
  songIds: string[],
  totalQuestions: number
): ComparisonPair[] {
  if (songIds.length < 2) return [];

  const pairs: ComparisonPair[] = [];
  const usedPairs = new Set<string>();

  // Pass 1: round-robin over a shuffled order, so early questions spread
  // coverage across the whole catalog instead of clustering randomly.
  const shuffled = shuffle(songIds);
  for (let i = 0; i + 1 < shuffled.length && pairs.length < totalQuestions; i += 2) {
    const a = shuffled[i];
    const b = shuffled[i + 1];
    pairs.push({ a, b });
    usedPairs.add(pairKey(a, b));
  }

  // Odd one out from pass 1, if any: give it a comparison too.
  if (shuffled.length % 2 === 1 && pairs.length < totalQuestions) {
    const leftover = shuffled[shuffled.length - 1];
    let partner = shuffled[Math.floor(Math.random() * (shuffled.length - 1))];
    let guard = 0;
    while ((partner === leftover || usedPairs.has(pairKey(leftover, partner))) && guard < 20) {
      partner = shuffled[Math.floor(Math.random() * shuffled.length)];
      guard++;
    }
    if (partner !== leftover) {
      pairs.push({ a: leftover, b: partner });
      usedPairs.add(pairKey(leftover, partner));
    }
  }

  // Pass 2: fill remaining slots with random pairs, preferring pairs not
  // used yet in this session.
  let safety = totalQuestions * 30;
  while (pairs.length < totalQuestions && safety > 0) {
    safety--;
    const a = songIds[Math.floor(Math.random() * songIds.length)];
    let b = songIds[Math.floor(Math.random() * songIds.length)];
    let guard = 0;
    while (b === a && guard < 20) {
      b = songIds[Math.floor(Math.random() * songIds.length)];
      guard++;
    }
    if (b === a) continue;

    const key = pairKey(a, b);
    if (usedPairs.has(key)) continue;

    pairs.push({ a, b });
    usedPairs.add(key);
  }

  return pairs;
}
