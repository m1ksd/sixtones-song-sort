import type { Song } from "../types/song";
import type { RatingsMap } from "../types/ranking";

export const INITIAL_RATING = 1500;
export const K_FACTOR = 32;

/** Creates a fresh ratings map, one entry per song, all starting at INITIAL_RATING. */
export function createInitialRatings(songs: Song[]): RatingsMap {
  const ratings: RatingsMap = {};
  for (const song of songs) {
    ratings[song.id] = {
      songId: song.id,
      rating: INITIAL_RATING,
      comparisons: 0,
    };
  }
  return ratings;
}

function expectedScore(ratingA: number, ratingB: number): number {
  return 1 / (1 + 10 ** ((ratingB - ratingA) / 400));
}

/**
 * Applies one Elo update for a single "A vs B" comparison.
 * Returns a new RatingsMap; does not mutate the input.
 */
export function applyResult(
  ratings: RatingsMap,
  winnerId: string,
  loserId: string,
  k: number = K_FACTOR
): RatingsMap {
  const winner = ratings[winnerId];
  const loser = ratings[loserId];
  if (!winner || !loser) return ratings;

  const expectedWinner = expectedScore(winner.rating, loser.rating);
  const expectedLoser = 1 - expectedWinner;

  const newWinnerRating = winner.rating + k * (1 - expectedWinner);
  const newLoserRating = loser.rating + k * (0 - expectedLoser);

  return {
    ...ratings,
    [winnerId]: {
      ...winner,
      rating: newWinnerRating,
      comparisons: winner.comparisons + 1,
    },
    [loserId]: {
      ...loser,
      rating: newLoserRating,
      comparisons: loser.comparisons + 1,
    },
  };
}

/** Returns song ids sorted by rating, descending. */
export function rankSongIds(ratings: RatingsMap): string[] {
  return Object.values(ratings)
    .slice()
    .sort((a, b) => b.rating - a.rating)
    .map((r) => r.songId);
}

/** Convenience: top N song ids by rating. */
export function topSongIds(ratings: RatingsMap, n: number): string[] {
  return rankSongIds(ratings).slice(0, n);
}
