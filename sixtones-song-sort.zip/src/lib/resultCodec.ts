import { songs } from "../data/songs";

// Bump this if the encoding scheme itself ever changes shape.
const CODEC_VERSION = "v1";

// A song's position in songs.ts is used as its compact numeric code.
// IMPORTANT: to keep old shared result links working, always ADD new
// songs to the end of the songs.ts list rather than reordering or
// removing existing entries.
const ID_TO_INDEX = new Map<string, number>(songs.map((s, i) => [s.id, i]));
const INDEX_TO_ID = new Map<number, string>(songs.map((s, i) => [i, s.id]));

const CODE_LENGTH = 2; // base36, 2 chars => up to 1295 songs supported

function toCode(index: number): string {
  return index.toString(36).padStart(CODE_LENGTH, "0");
}

function fromCode(code: string): number {
  return parseInt(code, 36);
}

/**
 * Encodes a TOP10 (ordered, best first) list of song ids into a compact,
 * URL-safe string. No personal data, no server round trip -- the whole
 * result lives in the URL itself.
 */
export function encodeResult(top10SongIds: string[]): string {
  const codes = top10SongIds
    .map((id) => ID_TO_INDEX.get(id))
    .filter((index): index is number => index !== undefined)
    .map(toCode);
  return `${CODEC_VERSION}.${codes.join("")}`;
}

/**
 * Decodes a result string back into an ordered list of song ids.
 * Returns null if the string is malformed or from an unsupported version.
 */
export function decodeResult(encoded: string): string[] | null {
  const [version, payload] = encoded.split(".");
  if (version !== CODEC_VERSION || !payload) return null;
  if (payload.length % CODE_LENGTH !== 0) return null;

  const ids: string[] = [];
  for (let i = 0; i < payload.length; i += CODE_LENGTH) {
    const chunk = payload.slice(i, i + CODE_LENGTH);
    const index = fromCode(chunk);
    const id = INDEX_TO_ID.get(index);
    if (!id) return null;
    ids.push(id);
  }
  return ids.length > 0 ? ids : null;
}
