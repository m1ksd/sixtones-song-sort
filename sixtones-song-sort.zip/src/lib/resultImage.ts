import type { Song } from "../types/song";

/**
 * Renders a simple, text-only TOP10 share image entirely in the browser
 * (Canvas API). Intentionally does not use any jacket art or official
 * imagery -- see project spec section 15.
 *
 * Returns a PNG data URL.
 */
export function generateResultImage(top10: Song[]): string {
  const width = 1080;
  const height = 1350;
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return "";

  // Background
  ctx.fillStyle = "#0a0a0b";
  ctx.fillRect(0, 0, width, height);

  // Hairline accent
  ctx.strokeStyle = "#c7c7cc";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(80, 120);
  ctx.lineTo(160, 120);
  ctx.stroke();

  // Title block
  ctx.fillStyle = "#9a9a9d";
  ctx.font = "500 32px 'Noto Sans JP', sans-serif";
  ctx.textBaseline = "alphabetic";
  ctx.fillText("SixTONES SONG SORT", 80, 100);

  ctx.fillStyle = "#f6f6f4";
  ctx.font = "900 64px 'Noto Sans JP', sans-serif";
  ctx.fillText("あなたのTOP10", 80, 210);

  // List
  const startY = 300;
  const rowHeight = (height - startY - 100) / 10;
  ctx.textBaseline = "middle";

  top10.slice(0, 10).forEach((song, i) => {
    const y = startY + rowHeight * i + rowHeight / 2;

    ctx.strokeStyle = "#2b2b2e";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(80, y - rowHeight / 2);
    ctx.lineTo(width - 80, y - rowHeight / 2);
    ctx.stroke();

    ctx.fillStyle = i < 3 ? "#eceef0" : "#c7c7cc";
    ctx.font = "700 40px 'Noto Sans JP', sans-serif";
    const rankText = String(i + 1).padStart(2, "0");
    ctx.fillText(rankText, 80, y);

    ctx.fillStyle = "#f6f6f4";
    ctx.font = "500 36px 'Noto Sans JP', sans-serif";
    const maxWidth = width - 220;
    let title = song.title;
    while (ctx.measureText(title).width > maxWidth && title.length > 1) {
      title = title.slice(0, -1);
    }
    if (title !== song.title) title += "…";
    ctx.fillText(title, 160, y);
  });

  ctx.fillStyle = "#9a9a9d";
  ctx.font = "400 24px 'Noto Sans JP', sans-serif";
  ctx.fillText("#SixTONESSongSort", 80, height - 50);

  return canvas.toDataURL("image/png");
}
