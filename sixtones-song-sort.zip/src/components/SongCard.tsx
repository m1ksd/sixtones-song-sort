type SongCardProps = {
  title: string;
  onSelect: () => void;
};

export function SongCard({ title, onSelect }: SongCardProps) {
  return (
    <button type="button" className="song-card" onClick={onSelect}>
      <span className="song-card__title">{title}</span>
    </button>
  );
}
