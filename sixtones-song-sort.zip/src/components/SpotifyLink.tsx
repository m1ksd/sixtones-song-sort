type SpotifyLinkProps = {
  url: string;
  songTitle: string;
};

export function SpotifyLink({ url, songTitle }: SpotifyLinkProps) {
  return (
    <a
      className="spotify-link"
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`${songTitle} を Spotify で聴く（新しいタブで開きます）`}
    >
      Spotifyで聴く
      <span aria-hidden="true" className="spotify-link__arrow">
        ↗
      </span>
    </a>
  );
}
