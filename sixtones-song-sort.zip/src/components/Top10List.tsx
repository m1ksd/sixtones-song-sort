import type { Song } from "../types/song";
import { SpotifyLink } from "./SpotifyLink";

type Top10ListProps = {
  songs: Song[];
};

export function Top10List({ songs }: Top10ListProps) {
  return (
    <ol className="top10-list">
      {songs.map((song, i) => (
        <li key={song.id} className="top10-list__item">
          <span className="top10-list__rank">{i + 1}</span>
          <span className="top10-list__title">{song.title}</span>
          {song.spotifyStatus === "confirmed" && song.spotifyUrl ? (
            <SpotifyLink url={song.spotifyUrl} songTitle={song.title} />
          ) : null}
        </li>
      ))}
    </ol>
  );
}
