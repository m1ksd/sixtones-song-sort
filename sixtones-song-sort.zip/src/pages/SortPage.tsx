import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { songs } from "../data/songs";
import { generateMatchupSequence } from "../lib/matchmaker";
import { applyResult, createInitialRatings, topSongIds } from "../lib/ranking";
import { encodeResult } from "../lib/resultCodec";
import { ProgressBar } from "../components/ProgressBar";
import { SongCard } from "../components/SongCard";
import type { RatingsMap } from "../types/ranking";

const TOTAL_QUESTIONS = 40;

export function SortPage() {
  const navigate = useNavigate();

  const songMap = useMemo(() => {
    const map = new Map<string, (typeof songs)[number]>();
    for (const s of songs) map.set(s.id, s);
    return map;
  }, []);

  const [pairs] = useState(() =>
    generateMatchupSequence(
      songs.map((s) => s.id),
      TOTAL_QUESTIONS
    )
  );
  const [ratings, setRatings] = useState<RatingsMap>(() => createInitialRatings(songs));
  const [questionIndex, setQuestionIndex] = useState(0);

  const totalQuestions = pairs.length;
  const currentPair = pairs[questionIndex];
  const songA = currentPair ? songMap.get(currentPair.a) : undefined;
  const songB = currentPair ? songMap.get(currentPair.b) : undefined;

  function handleChoice(winnerId: string, loserId: string) {
    const nextRatings = applyResult(ratings, winnerId, loserId);
    const nextIndex = questionIndex + 1;

    if (nextIndex >= totalQuestions) {
      const top10Ids = topSongIds(nextRatings, 10);
      const code = encodeResult(top10Ids);
      navigate(`/result/${code}`, { replace: true });
      return;
    }

    setRatings(nextRatings);
    setQuestionIndex(nextIndex);
  }

  if (!songA || !songB) {
    return (
      <div className="screen">
        <p>準備できませんでした。もう一度お試しください。</p>
      </div>
    );
  }

  return (
    <div className="screen sort-screen">
      <ProgressBar current={questionIndex + 1} total={totalQuestions} />

      <h2 className="sort-screen__prompt">どっちが好き？</h2>

      <div className="sort-screen__choices">
        <SongCard title={songA.title} onSelect={() => handleChoice(songA.id, songB.id)} />
        <div className="sort-screen__vs" aria-hidden="true">
          <span>VS</span>
        </div>
        <SongCard title={songB.title} onSelect={() => handleChoice(songB.id, songA.id)} />
      </div>
    </div>
  );
}
