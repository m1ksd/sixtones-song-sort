import { useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { songs } from "../data/songs";
import { decodeResult } from "../lib/resultCodec";
import { generateResultImage } from "../lib/resultImage";
import { Top10List } from "../components/Top10List";

export function ResultPage() {
  const { code } = useParams<{ code: string }>();
  const [copyState, setCopyState] = useState<"idle" | "copied" | "failed">("idle");

  const top10Songs = useMemo(() => {
    if (!code) return null;
    const ids = decodeResult(code);
    if (!ids) return null;
    const songMap = new Map(songs.map((s) => [s.id, s]));
    const resolved = ids.map((id) => songMap.get(id)).filter((s): s is (typeof songs)[number] => !!s);
    return resolved.length > 0 ? resolved : null;
  }, [code]);

  async function handleShare() {
    const shareUrl = window.location.href;
    const shareData = {
      title: "SixTONES SONG SORT",
      text: "私のSixTONES楽曲TOP10を作ったよ！",
      url: shareUrl,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
        return;
      } catch {
        // user cancelled or share failed; fall through to copy
      }
    }

    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopyState("copied");
      setTimeout(() => setCopyState("idle"), 2000);
    } catch {
      setCopyState("failed");
    }
  }

  function handleDownloadImage() {
    if (!top10Songs) return;
    const dataUrl = generateResultImage(top10Songs);
    if (!dataUrl) return;
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = "sixtones-song-sort-top10.png";
    a.click();
  }

  if (!top10Songs) {
    return (
      <div className="screen">
        <p className="result-screen__error">
          結果を読み込めませんでした。リンクが正しいかご確認ください。
        </p>
        <Link className="button button--primary" to="/">
          TOPへ戻る
        </Link>
      </div>
    );
  }

  return (
    <div className="screen result-screen">
      <div className="eyebrow-line" />
      <h1 className="result-screen__title">あなたのSixTONES TOP10</h1>

      <Top10List songs={top10Songs} />

      <div className="result-screen__actions">
        <button type="button" className="button button--primary" onClick={handleShare}>
          結果をシェア
        </button>
        <button type="button" className="button button--ghost" onClick={handleDownloadImage}>
          結果画像を保存
        </button>
        {copyState === "copied" && (
          <p className="result-screen__toast" role="status">
            リンクをコピーしました
          </p>
        )}
        {copyState === "failed" && (
          <p className="result-screen__toast" role="status">
            コピーに失敗しました。URLを手動でコピーしてください。
          </p>
        )}
      </div>

      <Link className="result-screen__retry" to="/sort">
        もう一度やってみる
      </Link>
    </div>
  );
}
