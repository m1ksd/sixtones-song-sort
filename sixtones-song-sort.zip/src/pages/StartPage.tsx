import { useNavigate } from "react-router-dom";

export function StartPage() {
  const navigate = useNavigate();

  return (
    <div className="screen start-screen">
      <div className="start-screen__body">
        <div className="eyebrow-line" />
        <h1 className="start-screen__title">
          SIXTONES
          <br />
          SONG SORT
        </h1>
        <p className="start-screen__copy">
          「どっちが好き？」を約40回。
          <br />
          あなただけのSixTONES楽曲TOP10を作ろう。
        </p>
      </div>

      <button
        type="button"
        className="button button--primary"
        onClick={() => navigate("/sort")}
      >
        START
      </button>

      <p className="start-screen__note">ファンメイドの非公式アプリです。</p>
    </div>
  );
}
