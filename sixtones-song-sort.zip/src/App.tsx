import { HashRouter, Route, Routes } from "react-router-dom";
import { StartPage } from "./pages/StartPage";
import { SortPage } from "./pages/SortPage";
import { ResultPage } from "./pages/ResultPage";

// HashRouter is used deliberately: this app is a static, backend-less
// GitHub Pages site, and hash-based routes (e.g. #/result/xxxx) work
// correctly on GitHub Pages / any static host without extra server
// config or a 404.html rewrite trick, including on a fresh page load
// of a shared result link.
export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<StartPage />} />
        <Route path="/sort" element={<SortPage />} />
        <Route path="/result/:code" element={<ResultPage />} />
      </Routes>
    </HashRouter>
  );
}
